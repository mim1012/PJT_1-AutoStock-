# 한국투자증권 API 설정
KIS_APP_KEY = "your_app_key_here"
KIS_APP_SECRET = "your_app_secret_here"
KIS_ACCOUNT_NUMBER = "your_account_number_here"

# API 엔드포인트
KIS_BASE_URL = "https://openapi.koreainvestment.com:9443"
KIS_PAPER_BASE_URL = "https://openapivts.koreainvestment.com:29443"  # 모의투자용

# 거래 설정
USE_PAPER_TRADING = True  # 모의투자 사용 여부
MAX_RETRY_COUNT = 3  # API 재시도 횟수
ORDER_TIMEOUT_MINUTES = 20  # 미체결 주문 취소 시간 (분)

# 전략 설정
PROFIT_THRESHOLD = 0.05  # 매도 수익률 임계값 (5%)
WATCH_LIST_FILE = "watch_list.txt"  # 관심종목 파일

# 상승 필터 종목 (NVDA, AMZN, MSFT)
FILTER_STOCKS = ["NVDA", "AMZN", "MSFT"]

# 운영 시간 설정 (미국 동부시간 기준)
TRADING_START_TIME = "11:30"
TRADING_END_TIME = "17:00"

# 스케줄 설정
SELL_INTERVAL_MINUTES = 30  # 매도 체크 주기 (분)
BUY_INTERVAL_MINUTES = 60   # 매수 체크 주기 (분)

# 로그 설정
LOG_LEVEL = "INFO"
LOG_FILE = "trading.log"

