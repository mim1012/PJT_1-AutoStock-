"""
PJT #1 매매 전략 구현
"""
import logging
from datetime import datetime, timedelta
from kis_api import KISAPIClient
from config import *

class TradingStrategy:
    def __init__(self):
        self.api_client = KISAPIClient()
        self.logger = logging.getLogger(__name__)
        self.last_sell_prices = {}  # 종목별 직전 매도가 저장
        self.last_buy_prices = {}   # 종목별 직전 매수가 저장
    
    def load_watch_list(self):
        """관심종목 리스트 로드"""
        try:
            with open(WATCH_LIST_FILE, 'r') as f:
                symbols = [line.strip() for line in f if line.strip()]
            self.logger.info(f"관심종목 로드 완료: {len(symbols)}개")
            return symbols
        except Exception as e:
            self.logger.error(f"관심종목 로드 실패: {e}")
            return []
    
    def check_filter_condition(self):
        """상승 필터 조건 확인 (NVDA, AMZN, MSFT 모두 상승)"""
        try:
            all_rising = True
            
            for symbol in FILTER_STOCKS:
                current_price = self.api_client.get_current_price(symbol)
                prev_close = self.api_client.get_previous_close(symbol)
                
                if current_price is None or prev_close is None:
                    self.logger.error(f"필터 종목 {symbol} 가격 조회 실패")
                    return False
                
                if current_price <= prev_close:
                    all_rising = False
                    self.logger.info(f"필터 조건 미충족: {symbol} 하락 중 (현재: ${current_price:.2f}, 전일: ${prev_close:.2f})")
                    break
                else:
                    self.logger.info(f"필터 종목 {symbol} 상승 중 (현재: ${current_price:.2f}, 전일: ${prev_close:.2f})")
            
            if all_rising:
                self.logger.info("상승 필터 조건 충족: 매수 허용")
            
            return all_rising
            
        except Exception as e:
            self.logger.error(f"필터 조건 확인 실패: {e}")
            return False
    
    def calculate_decline_rate(self, symbol):
        """전일 대비 하락률 계산"""
        try:
            current_price = self.api_client.get_current_price(symbol)
            prev_close = self.api_client.get_previous_close(symbol)
            
            if current_price is None or prev_close is None:
                return None
            
            decline_rate = (prev_close - current_price) / prev_close
            return decline_rate
            
        except Exception as e:
            self.logger.error(f"{symbol} 하락률 계산 실패: {e}")
            return None
    
    def get_top_declining_stocks(self, count=3):
        """가장 많이 하락한 종목 선정"""
        watch_list = self.load_watch_list()
        declining_stocks = []
        
        for symbol in watch_list:
            decline_rate = self.calculate_decline_rate(symbol)
            if decline_rate is not None and decline_rate > 0:  # 하락한 종목만
                declining_stocks.append((symbol, decline_rate))
        
        # 하락률 기준 내림차순 정렬
        declining_stocks.sort(key=lambda x: x[1], reverse=True)
        
        top_declining = declining_stocks[:count]
        self.logger.info(f"상위 하락 종목: {top_declining}")
        
        return [stock[0] for stock in top_declining]
    
    def calculate_position_size(self, symbol, available_cash):
        """매수 수량 계산 (예수금의 1/3 기준)"""
        try:
            current_price = self.api_client.get_current_price(symbol)
            if current_price is None:
                return 0
            
            allocation = available_cash / 3  # 1/3 할당
            quantity = int(allocation / current_price)
            
            self.logger.info(f"{symbol} 매수 수량 계산: ${allocation:.2f} / ${current_price:.2f} = {quantity}주")
            return quantity
            
        except Exception as e:
            self.logger.error(f"{symbol} 매수 수량 계산 실패: {e}")
            return 0
    
    def should_buy(self, symbol, current_price):
        """매수 조건 확인"""
        # 직전 매도가보다 낮은지 확인
        if symbol in self.last_sell_prices:
            if current_price >= self.last_sell_prices[symbol]:
                self.logger.info(f"{symbol} 매수 스킵: 현재가(${current_price}) >= 직전 매도가(${self.last_sell_prices[symbol]})")
                return False
        
        return True
    
    def execute_buy_strategy(self):
        """매수 전략 실행"""
        try:
            # 상승 필터 조건 확인
            if not self.check_filter_condition():
                self.logger.info("상승 필터 조건 미충족으로 매수 스킵")
                return
            
            # 계좌 잔고 조회
            balance = self.api_client.get_account_balance()
            if balance is None:
                self.logger.error("계좌 잔고 조회 실패")
                return
            
            available_cash = balance["cash"]
            self.logger.info(f"사용 가능 예수금: ${available_cash:.2f}")
            
            if available_cash < 100:  # 최소 $100 이상
                self.logger.info("예수금 부족으로 매수 스킵")
                return
            
            # 상위 하락 종목 선정
            top_declining = self.get_top_declining_stocks(3)
            
            for symbol in top_declining:
                current_price = self.api_client.get_current_price(symbol)
                if current_price is None:
                    continue
                
                if not self.should_buy(symbol, current_price):
                    continue
                
                quantity = self.calculate_position_size(symbol, available_cash)
                if quantity > 0:
                    order_id = self.api_client.place_order(symbol, quantity, current_price, "buy")
                    if order_id:
                        self.last_buy_prices[symbol] = current_price
                        self.logger.info(f"매수 주문 완료: {symbol} {quantity}주 @ ${current_price}")
                
        except Exception as e:
            self.logger.error(f"매수 전략 실행 실패: {e}")
    
    def calculate_profit_rate(self, symbol, current_price, avg_buy_price):
        """수익률 계산"""
        return (current_price - avg_buy_price) / avg_buy_price
    
    def should_sell(self, symbol, current_price):
        """매도 조건 확인"""
        # 직전 매수가보다 높은지 확인
        if symbol in self.last_buy_prices:
            if current_price < self.last_buy_prices[symbol]:
                self.logger.info(f"{symbol} 매도 스킵: 현재가(${current_price}) < 직전 매수가(${self.last_buy_prices[symbol]})")
                return False
        
        return True
    
    def execute_sell_strategy(self):
        """매도 전략 실행"""
        try:
            # 계좌 잔고 조회
            balance = self.api_client.get_account_balance()
            if balance is None:
                self.logger.error("계좌 잔고 조회 실패")
                return
            
            positions = balance["positions"]
            if not positions:
                self.logger.info("보유 종목 없음")
                return
            
            high_profit_stocks = []  # 5% 이상 수익 종목
            other_stocks = []        # 기타 종목
            
            for position in positions:
                symbol = position["ovrs_pdno"]
                quantity = int(position["ovrs_cblc_qty"])
                avg_buy_price = float(position["pchs_avg_pric"])
                
                if quantity <= 0:
                    continue
                
                current_price = self.api_client.get_current_price(symbol)
                if current_price is None:
                    continue
                
                profit_rate = self.calculate_profit_rate(symbol, current_price, avg_buy_price)
                
                if profit_rate >= PROFIT_THRESHOLD:  # 5% 이상 수익
                    high_profit_stocks.append((symbol, quantity, current_price, profit_rate))
                else:
                    other_stocks.append((symbol, quantity, current_price, profit_rate))
            
            # 5% 이상 수익 종목 즉시 매도
            for symbol, quantity, current_price, profit_rate in high_profit_stocks:
                if self.should_sell(symbol, current_price):
                    order_id = self.api_client.place_order(symbol, quantity, current_price, "sell")
                    if order_id:
                        self.last_sell_prices[symbol] = current_price
                        self.logger.info(f"고수익 매도: {symbol} {quantity}주 @ ${current_price} (수익률: {profit_rate:.2%})")
            
            # 기타 종목 중 수익률 가장 높은 종목 1개 매도
            if other_stocks:
                # 수익률 기준 내림차순 정렬
                other_stocks.sort(key=lambda x: x[3], reverse=True)
                
                best_stock = other_stocks[0]
                symbol, quantity, current_price, profit_rate = best_stock
                
                # 손실 종목은 매도하지 않음
                if profit_rate > 0 and self.should_sell(symbol, current_price):
                    order_id = self.api_client.place_order(symbol, quantity, current_price, "sell")
                    if order_id:
                        self.last_sell_prices[symbol] = current_price
                        self.logger.info(f"최고수익 매도: {symbol} {quantity}주 @ ${current_price} (수익률: {profit_rate:.2%})")
                
        except Exception as e:
            self.logger.error(f"매도 전략 실행 실패: {e}")

