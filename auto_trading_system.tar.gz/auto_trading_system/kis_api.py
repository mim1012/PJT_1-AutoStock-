"""
한국투자증권 OpenAPI 연동 모듈
"""
import requests
import json
import time
import logging
from datetime import datetime
from config import *

class KISAPIClient:
    def __init__(self):
        self.base_url = KIS_PAPER_BASE_URL if USE_PAPER_TRADING else KIS_BASE_URL
        self.app_key = KIS_APP_KEY
        self.app_secret = KIS_APP_SECRET
        self.account_number = KIS_ACCOUNT_NUMBER
        self.access_token = None
        self.token_expires_at = None
        
        # 로깅 설정
        logging.basicConfig(
            level=getattr(logging, LOG_LEVEL),
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(LOG_FILE),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def get_access_token(self):
        """액세스 토큰 발급"""
        url = f"{self.base_url}/oauth2/tokenP"
        headers = {"content-type": "application/json"}
        data = {
            "grant_type": "client_credentials",
            "appkey": self.app_key,
            "appsecret": self.app_secret
        }
        
        try:
            response = requests.post(url, headers=headers, data=json.dumps(data))
            response.raise_for_status()
            
            result = response.json()
            self.access_token = result["access_token"]
            self.token_expires_at = time.time() + result["expires_in"]
            
            self.logger.info("액세스 토큰 발급 성공")
            return True
            
        except Exception as e:
            self.logger.error(f"액세스 토큰 발급 실패: {e}")
            return False
    
    def ensure_token_valid(self):
        """토큰 유효성 확인 및 갱신"""
        if not self.access_token or time.time() >= self.token_expires_at - 300:
            return self.get_access_token()
        return True
    
    def get_headers(self, tr_id):
        """API 요청 헤더 생성"""
        return {
            "content-type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.access_token}",
            "appkey": self.app_key,
            "appsecret": self.app_secret,
            "tr_id": tr_id
        }
    
    def api_request(self, method, url, headers, params=None, data=None, retry_count=0):
        """API 요청 공통 함수"""
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=headers, params=params)
            else:
                response = requests.post(url, headers=headers, data=json.dumps(data) if data else None)
            
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            self.logger.error(f"API 요청 실패: {e}")
            
            if retry_count < MAX_RETRY_COUNT:
                self.logger.info(f"재시도 {retry_count + 1}/{MAX_RETRY_COUNT}")
                time.sleep(1)
                return self.api_request(method, url, headers, params, data, retry_count + 1)
            
            return None
    
    def get_previous_close(self, symbol):
        """전일 종가 조회"""
        if not self.ensure_token_valid():
            return None
        
        url = f"{self.base_url}/uapi/overseas-price/v1/quotations/dailyprice"
        headers = self.get_headers("HHDFS76240000")
        params = {
            "AUTH": "",
            "EXCD": "NAS",  # 나스닥
            "SYMB": symbol,
            "GUBN": "0",    # 일봉
            "BYMD": "",     # 조회기준일자 (공백시 최근일자)
            "MODP": "1"     # 수정주가반영여부
        }
        
        result = self.api_request("GET", url, headers, params=params)
        if result and result.get("rt_cd") == "0" and result.get("output2"):
            # 가장 최근 데이터의 종가 반환
            return float(result["output2"][0]["clos"])
        
        return None
    
    def get_current_price(self, symbol):
        """현재가 조회"""
        if not self.ensure_token_valid():
            return None
        
        url = f"{self.base_url}/uapi/overseas-price/v1/quotations/price"
        headers = self.get_headers("HHDFS00000300")
        params = {
            "AUTH": "",
            "EXCD": "NAS",  # 나스닥
            "SYMB": symbol
        }
        
        result = self.api_request("GET", url, headers, params=params)
        if result and result.get("rt_cd") == "0":
            return float(result["output"]["last"])
        
        return None
    
    def get_account_balance(self):
        """계좌 잔고 조회"""
        if not self.ensure_token_valid():
            return None
        
        url = f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-balance"
        headers = self.get_headers("JTTT3012R")
        params = {
            "CANO": self.account_number.split("-")[0],
            "ACNT_PRDT_CD": self.account_number.split("-")[1],
            "OVRS_EXCG_CD": "NASD",
            "TR_CRCY_CD": "USD",
            "CTX_AREA_FK200": "",
            "CTX_AREA_NK200": ""
        }
        
        result = self.api_request("GET", url, headers, params=params)
        if result and result.get("rt_cd") == "0":
            return {
                "cash": float(result["output2"][0]["frcr_dncl_amt_2"]),  # 예수금
                "positions": result["output1"]  # 보유종목
            }
        
        return None
    
    def place_order(self, symbol, quantity, price, order_type="buy"):
        """주문 실행"""
        if not self.ensure_token_valid():
            return None
        
        url = f"{self.base_url}/uapi/overseas-stock/v1/trading/order"
        
        # 매수/매도에 따른 TR_ID 설정
        tr_id = "JTTT1002U" if order_type == "buy" else "JTTT1006U"
        
        headers = self.get_headers(tr_id)
        data = {
            "CANO": self.account_number.split("-")[0],
            "ACNT_PRDT_CD": self.account_number.split("-")[1],
            "OVRS_EXCG_CD": "NASD",
            "PDNO": symbol,
            "ORD_QTY": str(quantity),
            "OVRS_ORD_UNPR": str(price),
            "ORD_SVR_DVSN_CD": "0",  # 지정가
            "ORD_DVSN": "00"  # 지정가
        }
        
        result = self.api_request("POST", url, headers, data=data)
        if result and result.get("rt_cd") == "0":
            order_id = result["output"]["ODNO"]
            self.logger.info(f"{order_type.upper()} 주문 성공: {symbol} {quantity}주 @ ${price} (주문번호: {order_id})")
            return order_id
        
        self.logger.error(f"{order_type.upper()} 주문 실패: {symbol}")
        return None
    
    def cancel_order(self, order_id, symbol):
        """주문 취소"""
        if not self.ensure_token_valid():
            return False
        
        url = f"{self.base_url}/uapi/overseas-stock/v1/trading/order-rvsecncl"
        headers = self.get_headers("JTTT1004U")
        data = {
            "CANO": self.account_number.split("-")[0],
            "ACNT_PRDT_CD": self.account_number.split("-")[1],
            "OVRS_EXCG_CD": "NASD",
            "PDNO": symbol,
            "ORGN_ODNO": order_id,
            "ORD_DVSN": "00",
            "RVSE_CNCL_DVSN_CD": "02"  # 취소
        }
        
        result = self.api_request("POST", url, headers, data=data)
        if result and result.get("rt_cd") == "0":
            self.logger.info(f"주문 취소 성공: {order_id}")
            return True
        
        self.logger.error(f"주문 취소 실패: {order_id}")
        return False
    
    def get_order_status(self, order_id):
        """주문 상태 조회"""
        if not self.ensure_token_valid():
            return None
        
        url = f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-nccs"
        headers = self.get_headers("JTTT3018R")
        params = {
            "CANO": self.account_number.split("-")[0],
            "ACNT_PRDT_CD": self.account_number.split("-")[1],
            "OVRS_EXCG_CD": "NASD",
            "SORT_SQN": "DS",
            "CTX_AREA_FK200": "",
            "CTX_AREA_NK200": ""
        }
        
        result = self.api_request("GET", url, headers, params=params)
        if result and result.get("rt_cd") == "0":
            for order in result["output"]:
                if order["odno"] == order_id:
                    return {
                        "status": order["ord_stat_cd"],  # 주문상태코드
                        "filled_qty": int(order["ccld_qty"]),  # 체결수량
                        "order_qty": int(order["ord_qty"])  # 주문수량
                    }
        
        return None

