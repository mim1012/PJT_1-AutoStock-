"""
API 연동 테스트 스크립트
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from kis_api import KISAPIClient
from config import *

def test_api_connection():
    """API 연결 테스트"""
    print("=== 한국투자증권 API 연결 테스트 ===")
    
    client = KISAPIClient()
    
    # 토큰 발급 테스트
    print("1. 액세스 토큰 발급 테스트...")
    if client.get_access_token():
        print("✓ 토큰 발급 성공")
    else:
        print("✗ 토큰 발급 실패")
        return False
    
    # 현재가 조회 테스트
    print("\n2. 현재가 조회 테스트...")
    test_symbols = ["AAPL", "NVDA", "TSLA"]
    
    for symbol in test_symbols:
        price = client.get_current_price(symbol)
        if price:
            print(f"✓ {symbol}: ${price:.2f}")
        else:
            print(f"✗ {symbol}: 조회 실패")
    
    # 계좌 잔고 조회 테스트
    print("\n3. 계좌 잔고 조회 테스트...")
    balance = client.get_account_balance()
    if balance:
        print(f"✓ 예수금: ${balance['cash']:.2f}")
        print(f"✓ 보유종목 수: {len(balance['positions'])}개")
        
        if balance['positions']:
            print("보유종목:")
            for pos in balance['positions'][:3]:  # 최대 3개만 표시
                symbol = pos.get('ovrs_pdno', 'N/A')
                qty = pos.get('ovrs_cblc_qty', '0')
                print(f"  - {symbol}: {qty}주")
    else:
        print("✗ 잔고 조회 실패")
    
    print("\n=== 테스트 완료 ===")
    return True

if __name__ == "__main__":
    # 설정 확인
    print("설정 확인:")
    print(f"- 모의투자 모드: {USE_PAPER_TRADING}")
    print(f"- API 키 설정: {'설정됨' if KIS_APP_KEY != 'your_app_key_here' else '미설정'}")
    print(f"- 계좌번호 설정: {'설정됨' if KIS_ACCOUNT_NUMBER != 'your_account_number_here' else '미설정'}")
    print()
    
    if KIS_APP_KEY == "your_app_key_here":
        print("⚠️  API 키가 설정되지 않았습니다.")
        print("config.py 파일에서 KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT_NUMBER를 설정해주세요.")
        sys.exit(1)
    
    test_api_connection()

