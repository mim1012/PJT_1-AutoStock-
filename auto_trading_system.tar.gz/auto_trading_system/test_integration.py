"""
통합 테스트 스크립트
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from kis_api import KISAPIClient
from strategy_pjt1 import TradingStrategy
from order_manager import OrderManager
from config import *

def test_strategy_logic():
    """전략 로직 테스트"""
    print("=== 전략 로직 테스트 ===")
    
    strategy = TradingStrategy()
    
    # 관심종목 로드 테스트
    print("1. 관심종목 로드 테스트...")
    watch_list = strategy.load_watch_list()
    if watch_list:
        print(f"✓ 관심종목 {len(watch_list)}개 로드 성공")
        print(f"  종목: {', '.join(watch_list[:5])}{'...' if len(watch_list) > 5 else ''}")
    else:
        print("✗ 관심종목 로드 실패")
    
    # 필터 조건 테스트
    print("\n2. 상승 필터 조건 테스트...")
    filter_result = strategy.check_filter_condition()
    print(f"{'✓' if filter_result else '✗'} 필터 조건 결과: {filter_result}")
    
    # 하락률 계산 테스트
    print("\n3. 하락률 계산 테스트...")
    test_symbols = ["AAPL", "NVDA", "TSLA"]
    
    for symbol in test_symbols:
        decline_rate = strategy.calculate_decline_rate(symbol)
        if decline_rate is not None:
            print(f"✓ {symbol}: {decline_rate:.2%} 하락")
        else:
            print(f"✗ {symbol}: 하락률 계산 실패")
    
    # 상위 하락 종목 선정 테스트
    print("\n4. 상위 하락 종목 선정 테스트...")
    top_declining = strategy.get_top_declining_stocks(3)
    if top_declining:
        print(f"✓ 상위 하락 종목: {', '.join(top_declining)}")
    else:
        print("✗ 하락 종목 선정 실패")

def test_order_manager():
    """주문 관리자 테스트"""
    print("\n=== 주문 관리자 테스트 ===")
    
    order_manager = OrderManager()
    
    # 주문 현황 조회 테스트
    print("1. 주문 현황 조회 테스트...")
    summary = order_manager.get_order_summary()
    print(f"✓ 현재 미체결 주문: {summary['total_pending']}개")
    print(f"  매수 주문: {summary['buy_orders']}개")
    print(f"  매도 주문: {summary['sell_orders']}개")

def test_configuration():
    """설정 테스트"""
    print("\n=== 설정 테스트 ===")
    
    # 필수 설정 확인
    config_items = [
        ("API 키", KIS_APP_KEY != "your_app_key_here"),
        ("API 시크릿", KIS_APP_SECRET != "your_app_secret_here"),
        ("계좌번호", KIS_ACCOUNT_NUMBER != "your_account_number_here"),
        ("관심종목 파일", os.path.exists(WATCH_LIST_FILE))
    ]
    
    for name, is_valid in config_items:
        print(f"{'✓' if is_valid else '✗'} {name}: {'설정됨' if is_valid else '미설정'}")
    
    # 운영 설정 확인
    print(f"\n운영 설정:")
    print(f"- 모의투자 모드: {USE_PAPER_TRADING}")
    print(f"- 운영 시간: {TRADING_START_TIME} ~ {TRADING_END_TIME}")
    print(f"- 매도 주기: {SELL_INTERVAL_MINUTES}분")
    print(f"- 매수 주기: {BUY_INTERVAL_MINUTES}분")
    print(f"- 수익률 임계값: {PROFIT_THRESHOLD:.1%}")
    print(f"- 주문 타임아웃: {ORDER_TIMEOUT_MINUTES}분")

def run_integration_test():
    """통합 테스트 실행"""
    print("=" * 50)
    print("한국투자증권 자동매매 시스템 통합 테스트")
    print("=" * 50)
    
    # 설정 테스트
    test_configuration()
    
    # API 연결 테스트 (실제 API 키가 있을 때만)
    if KIS_APP_KEY != "your_app_key_here":
        from test_api import test_api_connection
        test_api_connection()
        
        # 전략 로직 테스트
        test_strategy_logic()
    else:
        print("\n⚠️  API 키가 설정되지 않아 API 관련 테스트를 건너뜁니다.")
    
    # 주문 관리자 테스트
    test_order_manager()
    
    print("\n" + "=" * 50)
    print("통합 테스트 완료")
    print("=" * 50)

if __name__ == "__main__":
    run_integration_test()

