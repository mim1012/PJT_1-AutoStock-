# 한국투자증권 자동매매 시스템 v4.7

한국투자증권 OpenAPI를 사용한 미국/한국 주식 자동매매 시스템입니다.

## 주요 기능

- **듀얼 마켓 지원**: 미국 주식(NASDAQ, NYSE)과 한국 주식(KOSPI, KOSDAQ) 동시 거래
- **24시간 자동매매**: 시장 시간 자동 감지 및 스케줄링
- **토큰 자동 관리**: OAuth2 토큰 자동 발급/갱신 (24시간 제한 준수)
- **손절매 자동화**: 설정된 손실률 도달 시 자동 매도
- **모의투자 지원**: 실전 투자 전 안전한 테스트 가능

## 시스템 요구사항

- **OS**: Windows 10 이상
- **Python**: 3.8 이상 (3.11 권장)
- **인터넷**: 안정적인 인터넷 연결 필수
- **API 키**: 한국투자증권 OpenAPI 인증 정보 필요

## 설치 방법

### 1단계: Python 설치

[Python 공식 사이트](https://www.python.org/downloads/)에서 Python 3.11을 다운로드하여 설치합니다.

**중요**: 설치 시 "Add Python to PATH" 옵션을 반드시 체크하세요!

### 2단계: 패키지 설치

프로그램 폴더에서 명령 프롬프트(cmd)를 열고 다음 명령어를 실행하세요:

```bash
pip install -r requirements.txt
pip install mojito2
```

### 3단계: API 인증 정보 설정

#### 3-1. 한국투자증권 API 키 발급

1. [한국투자증권 API 포털](https://apiportal.koreainvestment.com) 접속
2. 회원가입 및 로그인
3. API 신청 → APP KEY, APP SECRET 발급
4. 계좌번호 확인

#### 3-2. 환경 변수 설정

`.env.example` 파일을 복사하여 `.env` 파일 생성:

```bash
copy .env.example .env
```

`.env` 파일을 메모장으로 열고 다음 정보를 입력:

```env
KIS_APP_KEY=발급받은_APP_KEY
KIS_APP_SECRET=발급받은_APP_SECRET
KIS_ACCOUNT_NUMBER=계좌번호
USE_PAPER_TRADING=True
```

**보안 주의**: `.env` 파일은 절대 다른 사람과 공유하지 마세요!

### 4단계: 종목 설정

#### 미국 주식 설정 (`stocks_config.json`)

```json
{
  "AAPL": {"exchange": "NASDAQ"},
  "TSLA": {"exchange": "NASDAQ"},
  "MSFT": {"exchange": "NASDAQ"}
}
```

#### 한국 주식 설정 (`kr_stocks_config.json`)

```json
{
  "005930": {"name": "삼성전자"},
  "000660": {"name": "SK하이닉스"}
}
```

## 실행 방법

### 자동 설치 및 실행

`setup.bat` 파일을 더블클릭하면 자동으로 설치 및 실행됩니다.

### 수동 실행

```bash
python main.py
```

또는 `start.bat` 파일을 더블클릭

## 주요 설정 (config.py)

```python
# 거래 모드
USE_PAPER_TRADING = True  # True: 모의투자, False: 실전투자

# 매매 스케줄
SELL_INTERVAL_MINUTES = 30  # 매도 체크 주기 (분)
BUY_INTERVAL_MINUTES = 60   # 매수 체크 주기 (분)

# 손절 설정
STOP_LOSS_THRESHOLD = -0.15  # 손절 기준 (-15%)
```

## 파일 구조

```
AutoTrading_Release/
├── common/                 # 공통 모듈
│   ├── base_token_manager.py  # 토큰 관리
│   ├── base_strategy.py       # 매매 전략 기반
│   └── base_api.py            # API 클라이언트 기반
├── us/                     # 미국 주식 모듈
│   ├── config.py              # 미국 시장 설정
│   ├── token_manager.py       # US 토큰 관리
│   └── strategy.py            # US 매매 전략
├── kr/                     # 한국 주식 모듈
│   ├── config.py              # 한국 시장 설정
│   ├── token_manager.py       # KR 토큰 관리
│   └── strategy.py            # KR 매매 전략
├── main.py                 # 메인 실행 파일
├── dual_market_scheduler.py  # 듀얼 마켓 스케줄러
├── config.py               # 전역 설정
├── requirements.txt        # Python 패키지 목록
├── .env.example            # 환경 변수 템플릿
├── stocks_config.json      # 미국 주식 종목 설정
└── kr_stocks_config.json   # 한국 주식 종목 설정
```

## 토큰 관리

### 토큰 파일 (자동 생성됨)

- `us_api_token.json` - 미국 주식 API 토큰
- `kr_api_token.json` - 한국 주식 API 토큰
- `us_krs_token.dat` - mojito2 US 토큰
- `kr_krs_token.dat` - mojito2 KR 토큰

### 24시간 제한

한국투자증권 API는 **하루에 1번만 토큰을 발급**할 수 있습니다. 토큰 파일을 삭제하거나 손상시키지 마세요!

### 토큰 문제 해결

토큰 오류 발생 시:

1. 프로그램 재시작 (자동으로 토큰 검증 및 갱신)
2. 24시간 이내 재발급 시도 시 다음날까지 대기
3. 토큰 파일이 손상되었을 경우에만 수동 삭제 후 재발급

## 로그 확인

모든 거래 내역과 오류는 `trading.log` 파일에 기록됩니다.

```bash
# 실시간 로그 확인 (PowerShell)
Get-Content trading.log -Wait -Tail 50
```

## 주의사항

### 1. 모의투자로 먼저 테스트
실전 투자 전에 반드시 `USE_PAPER_TRADING=True`로 설정하여 충분히 테스트하세요.

### 2. 24시간 제한
토큰 재발급은 하루에 1번만 가능합니다. 토큰 파일을 함부로 삭제하지 마세요.

### 3. 거래 시간
- 미국 시장: 23:30 ~ 06:00 (한국시간, 서머타임 고려)
- 한국 시장: 09:00 ~ 15:30 (한국시간)

### 4. 보안
- `.env` 파일은 절대 공유 금지
- API 키가 노출되면 즉시 재발급
- GitHub 등에 업로드 금지 (.gitignore 설정됨)

### 5. 책임
- 모든 투자 손실에 대한 책임은 사용자에게 있습니다
- 충분한 테스트 후 신중하게 사용하세요

## 문제 해결

### 토큰 발급 실패
- API 키 확인 (.env 파일)
- 24시간 제한 확인 (다음날 재시도)
- 인터넷 연결 확인

### 주문 실패
- 잔고 확인
- 거래 시간 확인
- 종목 코드 확인
- trading.log 파일 확인

### 프로그램 종료
- Python 버전 확인 (3.8 이상)
- 패키지 재설치: `pip install -r requirements.txt --force-reinstall`
- 로그 파일 확인

## 기술 지원

더 자세한 사용법은 `USER_MANUAL.md` 파일을 참고하세요.

---

**버전**: v4.7
**최종 업데이트**: 2026-01-26
**개발**: Claude Code with AI Agent
