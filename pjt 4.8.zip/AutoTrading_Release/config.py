# 한국투자증권 API 설정
# ⚠️ 보안을 위해 .env 파일에서 API 키를 로드합니다
# .env.example을 .env로 복사하고 실제 값을 입력하세요

import os
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# 환경변수에서 API 키 로드
KIS_APP_KEY = os.getenv("KIS_APP_KEY", "your_app_key_here")
KIS_APP_SECRET = os.getenv("KIS_APP_SECRET", "your_app_secret_here")
KIS_ACCOUNT_NUMBER = os.getenv("KIS_ACCOUNT_NUMBER", "your_account_number_here")

# API 키 검증
if KIS_APP_KEY == "your_app_key_here" or not KIS_APP_KEY:
    print("⚠️ WARNING: API 키가 설정되지 않았습니다!")
    print("   .env 파일을 생성하고 KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT_NUMBER를 설정하세요.")
    print("   자세한 내용은 .env.example 파일을 참조하세요.")

# API 엔드포인트 (해외주식 실거래용)
KIS_BASE_URL = "https://openapi.koreainvestment.com:9443"  # 해외주식 실거래
KIS_PAPER_BASE_URL = "https://openapivts.koreainvestment.com:29443"  # 해외주식 모의투자

# 거래 설정
USE_PAPER_TRADING = os.getenv("USE_PAPER_TRADING", "False").lower() in ("true", "1", "yes")
MAX_RETRY_COUNT = 3  # API 재시도 횟수
ORDER_TIMEOUT_MINUTES = 20  # 미체결 주문 취소 시간 (분)

# 전략 설정
STOCKS_CONFIG_FILE = "stocks_config.json"
PROFIT_THRESHOLD = 0.05  # 매도 수익률 임계값 (5%)
CHECK_PREVIOUS_SELL_PRICE = True  # True = 이전 매도가보다 높으면 재매수 금지

# 운영 시간 설정 (미국 동부시간 EST/EDT 기준)
TRADING_START_TIME = "09:30"  # 미국 주식 시장 개장 시간 (ET)
TRADING_END_TIME = "16:00"    # 미국 주식 시장 폐장 시간 (ET)

# 스케줄 설정
SELL_INTERVAL_MINUTES = 30  # 매도 체크 주기 (분)
BUY_INTERVAL_MINUTES = 60   # 매수 체크 주기 (분)

# 로그 설정
LOG_LEVEL = "INFO"
LOG_FILE = "trading.log"
LOG_MAX_BYTES = 10 * 1024 * 1024  # 10MB
LOG_BACKUP_COUNT = 5  # 최대 5개 백업

# 전일 종가 조회 시 시도할 필드명들 (KIS API 응답 구조 대응)
possible_fields = ["clos", "last", "prvs_clpr", "stck_clpr", "base_pric"]