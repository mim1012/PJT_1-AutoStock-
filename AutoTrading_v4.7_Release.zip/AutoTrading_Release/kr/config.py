# -*- coding: utf-8 -*-
"""
한국 주식 전용 설정

KRX (KOSPI/KOSDAQ) 거래를 위한 설정
"""
import os
import sys

# 프로젝트 루트를 경로에 추가
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from config import (
    KIS_APP_KEY,
    KIS_APP_SECRET,
    KIS_ACCOUNT_NUMBER,
    USE_PAPER_TRADING,
    KIS_BASE_URL,
    KIS_PAPER_BASE_URL
)


class KRConfig:
    """한국 주식 설정 클래스"""

    # ============================================
    # 시장 설정
    # ============================================
    TIMEZONE = "Asia/Seoul"
    TRADING_START_TIME = "09:00"  # 장 시작
    TRADING_END_TIME = "15:30"    # 장 종료

    # ============================================
    # 매매 설정
    # ============================================
    STOP_LOSS_THRESHOLD = -0.15      # 손절 기준 -15%
    STOP_LOSS_COOLDOWN_DAYS = 50     # 손절 후 재매수 금지 기간 (일)

    # ============================================
    # 파일 설정
    # ============================================
    STOCKS_CONFIG_FILE = "kr_stocks_config.json"
    TOKEN_FILE_PREFIX = "kr"

    # ============================================
    # 호가 단위 (KRX 규정)
    # ============================================
    TICK_SIZES = [
        (2000, 1),
        (5000, 5),
        (20000, 10),
        (50000, 50),
        (200000, 100),
        (500000, 500),
        (float('inf'), 1000)
    ]

    @classmethod
    def get_credentials(cls):
        """API 인증 정보 반환"""
        return KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT_NUMBER

    @classmethod
    def get_api_url(cls):
        """API URL 반환 (실전/모의 자동 선택)"""
        if USE_PAPER_TRADING:
            return KIS_PAPER_BASE_URL
        return KIS_BASE_URL

    @classmethod
    def is_paper_trading(cls):
        """모의투자 여부 반환"""
        return USE_PAPER_TRADING

    @classmethod
    def round_to_tick(cls, price: float) -> int:
        """
        가격을 호가 단위에 맞게 조정

        KRX 호가 단위:
        - 2,000원 미만: 1원
        - 2,000원 이상 5,000원 미만: 5원
        - 5,000원 이상 20,000원 미만: 10원
        - 20,000원 이상 50,000원 미만: 50원
        - 50,000원 이상 200,000원 미만: 100원
        - 200,000원 이상 500,000원 미만: 500원
        - 500,000원 이상: 1,000원

        Args:
            price: 원래 가격

        Returns:
            호가 단위에 맞춘 가격
        """
        for threshold, tick in cls.TICK_SIZES:
            if price < threshold:
                return int(price // tick) * tick

        # 기본값 (500,000원 이상)
        return int(price // 1000) * 1000

    @classmethod
    def get_tick_size(cls, price: float) -> int:
        """해당 가격대의 호가 단위 반환"""
        for threshold, tick in cls.TICK_SIZES:
            if price < threshold:
                return tick
        return 1000
