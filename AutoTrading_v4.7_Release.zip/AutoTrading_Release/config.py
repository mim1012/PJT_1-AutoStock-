# -*- coding: utf-8 -*-
"""
전역 설정 파일

.env 파일에서 환경 변수를 로드하여 설정합니다.
실전 투자 시 USE_PAPER_TRADING=False로 설정하세요.
"""
import os
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# ============================================
# API 인증 정보 (.env에서 로드)
# ============================================
KIS_APP_KEY = os.getenv('KIS_APP_KEY', '')
KIS_APP_SECRET = os.getenv('KIS_APP_SECRET', '')
KIS_ACCOUNT_NUMBER = os.getenv('KIS_ACCOUNT_NUMBER', '')

# ============================================
# 거래 모드 설정
# ============================================
# True: 모의투자, False: 실전투자
USE_PAPER_TRADING = os.getenv('USE_PAPER_TRADING', 'False').lower() in ('true', '1', 'yes')

# ============================================
# API URL 설정
# ============================================
KIS_BASE_URL = "https://openapi.koreainvestment.com:9443"  # 실전투자
KIS_PAPER_BASE_URL = "https://openapivts.koreainvestment.com:29443"  # 모의투자

# ============================================
# 매매 설정
# ============================================
PROFIT_THRESHOLD = 0.05  # 목표 수익률 5%
STOP_LOSS_THRESHOLD = -0.15  # 손절 기준 -15%

# ============================================
# 스케줄 설정 (분 단위)
# ============================================
SELL_INTERVAL_MINUTES = 30  # 매도 체크 주기
BUY_INTERVAL_MINUTES = 60   # 매수 체크 주기

# ============================================
# 거래 시간 (참고용 - 실제는 각 시장 config에서 관리)
# ============================================
TRADING_START_TIME = "09:30"  # 미국 시장 시작 (ET)
TRADING_END_TIME = "16:00"    # 미국 시장 종료 (ET)

# ============================================
# 로그 설정
# ============================================
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = "trading.log"
LOG_MAX_BYTES = 10 * 1024 * 1024  # 10MB
LOG_BACKUP_COUNT = 5

# ============================================
# 설정 검증
# ============================================
def validate_config():
    """설정 유효성 검사"""
    errors = []

    if not KIS_APP_KEY:
        errors.append("KIS_APP_KEY가 설정되지 않았습니다.")
    if not KIS_APP_SECRET:
        errors.append("KIS_APP_SECRET이 설정되지 않았습니다.")
    if not KIS_ACCOUNT_NUMBER:
        errors.append("KIS_ACCOUNT_NUMBER가 설정되지 않았습니다.")
    elif '-' not in KIS_ACCOUNT_NUMBER:
        errors.append("KIS_ACCOUNT_NUMBER 형식 오류: 하이픈(-) 필요 (예: 12345678-01)")

    if errors:
        print("=" * 50)
        print("[CONFIG ERROR] 설정 오류:")
        for err in errors:
            print(f"  - {err}")
        print("=" * 50)
        print(".env 파일을 확인하세요.")
        return False

    return True


# 모듈 로드 시 설정 출력
if __name__ != "__main__":
    mode = "모의투자" if USE_PAPER_TRADING else "실전투자"
    print(f"[CONFIG] 거래 모드: {mode}")
    print(f"[CONFIG] 목표 수익률: {PROFIT_THRESHOLD*100:.1f}%")
    print(f"[CONFIG] 손절 기준: {STOP_LOSS_THRESHOLD*100:.1f}%")
