# -*- coding: utf-8 -*-
"""
미국 주식 전용 설정

NASDAQ/NYSE 거래를 위한 설정
"""
import os
import sys

# 프로젝트 루트를 경로에 추가
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from config import (
    KIS_APP_KEY,
    KIS_APP_SECRET,
    KIS_ACCOUNT_NUMBER,
    USE_PAPER_TRADING,
    KIS_BASE_URL,
    KIS_PAPER_BASE_URL
)


class USConfig:
    """미국 주식 설정 클래스"""

    # ============================================
    # 시장 설정
    # ============================================
    TIMEZONE = "US/Eastern"
    TRADING_START_TIME = "09:30"  # 장 시작 (ET)
    TRADING_END_TIME = "16:00"    # 장 종료 (ET)

    # ============================================
    # 매매 설정
    # ============================================
    STOP_LOSS_THRESHOLD = -0.15      # 손절 기준 -15%
    STOP_LOSS_COOLDOWN_DAYS = 50     # 손절 후 재매수 금지 기간 (일)

    # ============================================
    # 파일 설정
    # ============================================
    STOCKS_CONFIG_FILE = "us_stocks_config.json"
    TOKEN_FILE_PREFIX = "us"
    MOJITO_TOKEN_FILE = "us_krs_token.dat"  # mojito2 토큰 파일

    # ============================================
    # 거래소 설정
    # ============================================
    EXCHANGES = {
        'NASDAQ': 'NAS',
        'NYSE': 'NYS',
        'AMEX': 'AMS'
    }

    @classmethod
    def get_credentials(cls):
        """API 인증 정보 반환"""
        return KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT_NUMBER

    @classmethod
    def get_api_url(cls):
        """API URL 반환 (실전/모의 자동 선택)"""
        if USE_PAPER_TRADING:
            return KIS_PAPER_BASE_URL
        return KIS_BASE_URL

    @classmethod
    def is_paper_trading(cls):
        """모의투자 여부 반환"""
        return USE_PAPER_TRADING

    @classmethod
    def get_exchange_code(cls, exchange_name: str) -> str:
        """
        거래소 이름을 API 코드로 변환

        Args:
            exchange_name: 거래소 이름 (NASDAQ, NYSE, AMEX)

        Returns:
            API 거래소 코드 (NAS, NYS, AMS)
        """
        return cls.EXCHANGES.get(exchange_name.upper(), 'NAS')
