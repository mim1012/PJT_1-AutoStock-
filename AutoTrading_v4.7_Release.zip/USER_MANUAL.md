# 자동매매 시스템 사용자 매뉴얼

## 목차

1. [빠른 시작 가이드](#빠른-시작-가이드)
2. [상세 설정 방법](#상세-설정-방법)
3. [매매 전략 설정](#매매-전략-설정)
4. [문제 해결](#문제-해결)
5. [FAQ](#faq)

---

## 빠른 시작 가이드

### 1분 만에 시작하기

1. **setup.bat 실행** (더블클릭)
   - 자동으로 모든 패키지 설치
   - .env 파일 자동 생성 및 편집창 열림

2. **.env 파일에 API 키 입력**
   ```env
   KIS_APP_KEY=PS12345678901234567890
   KIS_APP_SECRET=abcd1234...
   KIS_ACCOUNT_NUMBER=12345678-01
   USE_PAPER_TRADING=True
   ```

3. **start.bat 실행** (더블클릭)
   - 자동으로 프로그램 시작
   - 모의투자로 안전하게 테스트

### 처음 사용자를 위한 체크리스트

- [ ] Python 3.8 이상 설치
- [ ] 한국투자증권 API 키 발급 완료
- [ ] .env 파일에 API 키 입력
- [ ] USE_PAPER_TRADING=True 설정 (모의투자)
- [ ] stocks_config.json 파일에 거래 종목 설정
- [ ] 최소 1주일 이상 모의투자 테스트

---

## 상세 설정 방법

### API 키 발급 상세 가이드

#### 1단계: 한국투자증권 계좌 개설
- 한국투자증권 홈페이지 또는 앱에서 계좌 개설
- 비대면 계좌 개설 가능 (신분증 필요)

#### 2단계: API 포털 접속
1. https://apiportal.koreainvestment.com 접속
2. 회원가입 (증권 계좌 번호 필요)
3. 로그인

#### 3단계: 앱 등록
1. "My App" → "신규 등록"
2. 앱 이름 입력 (예: "자동매매봇")
3. 서비스 선택:
   - 국내주식 시세 조회
   - 국내주식 주문
   - 해외주식 시세 조회
   - 해외주식 주문

#### 4단계: 키 발급
- **APP KEY**: 앱 식별 키 (공개 가능)
- **APP SECRET**: 비밀 키 (절대 공유 금지!)
- 발급된 키를 안전한 곳에 보관

#### 5단계: 모의투자 신청
1. "모의투자 신청" 메뉴
2. 계좌 개설 (가상 자금 지급)
3. 모의투자 계좌번호 확인

### 환경 변수 상세 설정

```env
# ===== 필수 설정 =====
KIS_APP_KEY=PS12345678901234567890
KIS_APP_SECRET=1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefghijklmnopqr
KIS_ACCOUNT_NUMBER=12345678-01
USE_PAPER_TRADING=True

# ===== 선택 설정 =====
# 로그 레벨 (DEBUG, INFO, WARNING, ERROR)
# LOG_LEVEL=INFO

# 타임아웃 설정 (초)
# API_TIMEOUT=30
```

### 종목 설정 상세 가이드

#### 미국 주식 설정 (stocks_config.json)

```json
{
  "AAPL": {
    "exchange": "NASDAQ",
    "name": "Apple Inc.",
    "enabled": true
  },
  "TSLA": {
    "exchange": "NASDAQ",
    "name": "Tesla Inc.",
    "enabled": true
  },
  "MSFT": {
    "exchange": "NASDAQ",
    "name": "Microsoft Corp.",
    "enabled": false
  }
}
```

**주요 거래소 코드**:
- `NASDAQ`: 나스닥
- `NYSE`: 뉴욕증권거래소
- `AMEX`: 아메리칸증권거래소

#### 한국 주식 설정 (kr_stocks_config.json)

```json
{
  "005930": {
    "name": "삼성전자",
    "enabled": true
  },
  "000660": {
    "name": "SK하이닉스",
    "enabled": true
  },
  "035420": {
    "name": "NAVER",
    "enabled": false
  }
}
```

**종목 코드 찾기**:
- 네이버 금융, 다음 금융에서 검색
- 6자리 숫자 코드 사용
- 예: 삼성전자 = 005930

---

## 매매 전략 설정

### 기본 전략 파라미터 (config.py)

```python
# 거래 모드
USE_PAPER_TRADING = True  # True: 모의투자, False: 실전투자

# 스케줄 설정
SELL_INTERVAL_MINUTES = 30  # 매도 체크 주기 (분)
BUY_INTERVAL_MINUTES = 60   # 매수 체크 주기 (분)

# 손절매 설정
STOP_LOSS_THRESHOLD = -0.15      # 손절 기준 (-15%)
STOP_LOSS_COOLDOWN_DAYS = 100    # 손절 후 재매수 금지 기간 (일)

# 수익 목표
PROFIT_THRESHOLD = 0.05  # 목표 수익률 (+5%)

# 주문 설정
MAX_RETRY_COUNT = 3           # 주문 재시도 횟수
ORDER_TIMEOUT_MINUTES = 5     # 주문 타임아웃 (분)
```

### 시장별 차이점

#### 미국 시장 (us/config.py)
```python
# 거래 시간 (한국시간)
TRADING_START_TIME = "23:30"  # 밤 11:30
TRADING_END_TIME = "06:00"    # 아침 6:00

# 손절 설정
STOP_LOSS_THRESHOLD = -0.15   # -15%
STOP_LOSS_COOLDOWN_DAYS = 100 # 100일
```

#### 한국 시장 (kr/config.py)
```python
# 거래 시간
TRADING_START_TIME = "09:00"
TRADING_END_TIME = "15:30"

# 손절 설정
STOP_LOSS_THRESHOLD = -0.10   # -10%
STOP_LOSS_COOLDOWN_DAYS = 50  # 50일

# 세금/수수료
SELLING_TAX_RATE = 0.0023     # 증권거래세 0.23%
COMMISSION_RATE = 0.00015     # 수수료 0.015%
```

### 전략 커스터마이징

매매 전략을 수정하려면:

1. **미국 주식**: `us/strategy.py` 파일 수정
2. **한국 주식**: `kr/strategy.py` 파일 수정

```python
# 예시: 매수 조건 변경 (us/strategy.py)
def should_buy(self, symbol, current_price):
    """매수 판단 로직"""
    # 여기에 커스텀 로직 추가
    # 예: RSI, 이동평균선, 볼린저밴드 등

    # 기본: 보유하지 않은 종목만 매수
    if symbol in self.positions:
        return False

    # 추가 조건 예시
    # if self.calculate_rsi(symbol) < 30:  # RSI 과매도
    #     return True

    return True  # 기본 매수
```

---

## 문제 해결

### 토큰 관련 오류

#### "24시간 이내 토큰 재발급 불가"
```
[ERROR] 24시간 이내 재발급 불가. 마지막 발급: 2026-01-26 10:30:00
```

**해결 방법**:
- 다음날까지 대기 (한국투자증권 정책)
- 토큰 파일(`*_api_token.json`)을 삭제하지 말 것
- 자정 이후 자동으로 재발급 가능

#### "토큰 만료" 오류
```
[ERROR] Token expired
```

**해결 방법**:
1. 프로그램 재시작 (자동 갱신 시도)
2. 24시간 경과 시 자동으로 재발급
3. 토큰 파일 확인: `ls *_token.json`

### 주문 관련 오류

#### "잔고 부족"
```
[ERROR] 매수 가능 금액 부족
```

**해결 방법**:
- 모의투자: 초기 자금 확인 (1억원)
- 실전투자: 실제 잔고 확인
- `trading.log`에서 현재 잔고 확인

#### "주문 체결 안됨"
```
[WARN] 주문 미체결: AAPL
```

**가능한 원인**:
- 시장 시간 외 주문
- 호가 범위 초과
- 주문 수량 문제

**해결 방법**:
```bash
# 로그 확인
type trading.log | findstr "주문"

# 거래 시간 확인
# 미국: 23:30-06:00 (한국시간)
# 한국: 09:00-15:30
```

### 네트워크 관련 오류

#### "Connection timeout"
```
[ERROR] Connection timeout to KIS API
```

**해결 방법**:
1. 인터넷 연결 확인
2. 방화벽 설정 확인
3. API 서버 상태 확인: https://apiportal.koreainvestment.com

#### "API Rate Limit"
```
[ERROR] API rate limit exceeded
```

**해결 방법**:
- 호출 주기 늘리기 (config.py)
- 잠시 대기 후 재시도
- 불필요한 API 호출 제거

### 프로그램 실행 오류

#### "ModuleNotFoundError"
```
ModuleNotFoundError: No module named 'requests'
```

**해결 방법**:
```bash
# 패키지 재설치
pip install -r requirements.txt --force-reinstall
pip install mojito2
```

#### "Python not found"
```
'python' is not recognized as an internal or external command
```

**해결 방법**:
1. Python 재설치
2. "Add Python to PATH" 옵션 체크
3. 시스템 재시작

---

## FAQ

### Q1. 실전 투자는 언제 시작해야 하나요?
**A**: 최소 1주일 이상 모의투자로 충분히 테스트한 후, 시스템이 안정적으로 동작하는 것을 확인하고 시작하세요. 처음에는 소액으로 시작하는 것을 권장합니다.

### Q2. 손절매 비율을 어떻게 설정해야 하나요?
**A**:
- 보수적: -5% ~ -10%
- 중립적: -10% ~ -15% (기본값)
- 공격적: -15% ~ -20%

개인의 위험 감수 성향과 종목 변동성을 고려하여 설정하세요.

### Q3. 여러 PC에서 동시 실행 가능한가요?
**A**: 아니요. 한국투자증권 API는 동일한 계정으로 동시 접속 시 토큰 충돌이 발생할 수 있습니다. 하나의 PC에서만 실행하세요.

### Q4. 토큰을 매일 수동으로 재발급해야 하나요?
**A**: 아니요. 시스템이 자동으로 토큰 만료를 감지하고 재발급합니다. 단, 24시간 제한으로 하루에 1번만 재발급 가능합니다.

### Q5. 거래 시간 외에도 프로그램을 켜둬야 하나요?
**A**: 아니요. 필요 시에만 실행하면 됩니다. 다만, 24시간 자동매매를 원하시면 계속 실행해두셔야 합니다.

### Q6. 로그는 어디서 확인하나요?
**A**: `trading.log` 파일에서 모든 거래 내역과 오류를 확인할 수 있습니다.

```bash
# 실시간 로그 확인 (PowerShell)
Get-Content trading.log -Wait -Tail 50

# 최근 100줄만 보기
Get-Content trading.log -Tail 100
```

### Q7. 종목을 중간에 추가/제거할 수 있나요?
**A**: 네. `stocks_config.json` 또는 `kr_stocks_config.json` 파일을 수정하고 프로그램을 재시작하면 됩니다.

### Q8. 수익률은 어디서 확인하나요?
**A**:
- 로그 파일: `trading.log`
- 한국투자증권 MTS/HTS 앱
- 웹 트레이딩 시스템

향후 업데이트에서 웹 대시보드를 추가할 예정입니다.

### Q9. 프로그램이 갑자기 종료되면?
**A**:
1. `trading.log` 파일에서 오류 확인
2. 토큰 파일 확인 (`*_token.json`)
3. 인터넷 연결 확인
4. 재시작: `start.bat` 실행

### Q10. API 키가 노출되었어요!
**A**:
1. 즉시 한국투자증권 API 포털에서 키 삭제
2. 새로운 앱 등록 및 키 재발급
3. `.env` 파일 업데이트
4. `.env` 파일 보안 강화 (읽기 전용으로 설정)

---

## 추가 리소스

### 공식 문서
- [한국투자증권 API 포털](https://apiportal.koreainvestment.com)
- [API 개발 가이드](https://apiportal.koreainvestment.com/apiservice/)

### 커뮤니티
- 한국투자증권 개발자 포럼
- Python 자동매매 커뮤니티

### 업데이트
- 최신 버전 확인
- 버그 리포트 제출

---

**문의사항이 있으시면 README.md 파일의 기술 지원 섹션을 참고하세요.**

**버전**: v4.7
**최종 업데이트**: 2026-01-26
